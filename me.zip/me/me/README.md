# Landing Page Project

## Table of Contents

- [InstructionsOfTheProject](#instructions)
- [DevelopmentTips](#development)
- [ES6AndJS](#es6)
- [Done](#done)

# InstructionsOfTheProject :

The starter project has some HTML and CSS styling to display a static version of
the Landing Page project.

open `js/app.js` and start it


# DevelopmentTips :

To run this project locally, in your development folder please run
`npx http-server -c-1 -o` to run a local development server which has no-cache
enabled and automatically opening your standard browser. Make some changes and
reload the browser and the changes are applied.

Enjoy!

# ES6AndJS :

I did use several ES6 methods and Javascript and browser functions which are
only available in the latest modern browsers, like `IntersectionObserver`.
Though those are working with the latest browsers except IE 11, IE 10 and Opera
mobile.

Most of the changes have happened in the `js/app.js` file and some changes for
styling in `styles.css`

# Done : 

This project has been enhanced with dynamic generated Navigation list (based on
the sections) in an unordered list as well as scolling to the section.
